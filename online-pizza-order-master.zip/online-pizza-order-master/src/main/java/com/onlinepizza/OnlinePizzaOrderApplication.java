package com.onlinepizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePizzaOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePizzaOrderApplication.class, args);
	}

}
